#include<iostream>
#include<ctime>
#include<string>
using namespace std;
class Date{
	public :
		Date( );
		Date(int y,int m,int d);
		void setDate(int y,int m,int d);
		void print();
	protected :
		int year,month,day;

};
Date::Date( ){
	tm *t;
	time_t t1=time(0);
	t=localtime(&t1);
	year=t->tm_year+1900;
	month=t->tm_mon+1;
	day=t->tm_mday;
}
Date::Date(int y,int m,int d)
{
	year=y;
	month=m;
	day=d;
}
void Date::setDate(int y,int m,int d)

{

	year=y;
	month=m;
	day=d;

}
void Date::print(){
	cout<<"Date--->: ";
	cout<<month<<"-"<<day<<"-"<<year<<endl;

}

class ShortE:public Date{

	public :
		ShortE(){ } 
		ShortE(int y,int m,int d):Date(y,m,d){ }
	void print(){
		cout<<"ShortE--->: ";
		cout<<day<<"-"<<month<<"-"<<year<<endl;
	}

};

class MediumDate:public Date{
	public :

		MediumDate() { }
		MediumDate(int y,int m,int d):Date(y,m,d){  }
		void print(){
			string s[12]={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
			cout<<"MediumDate--->: ";
			cout<<s[month-1]<<"."<<day<<","<<year<<endl;
		}
};
class LongDate:public Date{
	public :
		LongDate(){ }
		LongDate(int y,int m,int d):Date(y,m,d){ }
		void print(){
			string s[12]={"January","February","March","April","May","June","July","August","September","October","November","December"};
			cout<<"LonngDate--->: ";
			cout<<s[month-1]<<" "<<day<<","<<year<<endl;
		}
};
void main(){

	int year,month,day;



	Date t;//
	ShortE s;//
	MediumDate m;//
	LongDate l;//
	cin>>year>>month>>day;


	t.setDate(year,month,day);
	s.setDate(year,month,day);
	m.setDate(year,month,day);
	l.setDate(year,month,day);
	t.print();
	s.print();
	m.print();
	l.print();



}