
#include "filmrev.h"
int main( )
{
	const unsigned n=5;
	Film*films[n];
	if(!Film::read_input("films.dat",films,n)){
		cerr<<"Unable to read file films.dat:exiting."<<endl;
		exit(EXIT_FAILURE);
	}


	for(unsigned i=0;i<n;i++)
		films[i]->output();
	return 0;
}
