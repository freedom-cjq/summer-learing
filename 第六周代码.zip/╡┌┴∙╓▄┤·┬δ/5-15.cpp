#include <iostream>
using namespace std;
class B{
public:
	virtual void m(int x){cout<<x<<endl;}
};
class D:public B{
public:
	void m( ){cout<<"Hi"<<endl;}
};
int main()
{
	D d1;
	d1.m();

	d1.m(26);//error
	return 0;
}