#include  <iostream>
using namespace std;
class B{
public:
	virtual void m( ){cout<<"B::m"<<endl;}
};
class D:public B{
public:
	void m(){cout<<"D::m"<<endl;}
};
int main(){
	B*p;
	p=new D;
	p->m( );
	return 0;
}
