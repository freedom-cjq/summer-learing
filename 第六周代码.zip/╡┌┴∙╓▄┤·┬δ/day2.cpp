#include <iostream>
#include<iomanip>
#include<ctime>
using namespace std;
class Date
{
public:
	Date( )
	{
		tm * t;
		time_t  t1=time(0);
		t=localtime(&t1);
		year=t->tm_year+1900;
		month=t->tm_mon+1;
		day=t->tm_mday;  

	}
	void display()
	{ cout<<setfill('0');
		                  
	  cout<<setw(2)<<day<<"-"<<setw(2)<<month<<"-"<<year<<endl;  
	}
private:
	int year,month,day;
};
void main()
{
	Date d;
	d.display();

}